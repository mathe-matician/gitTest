from setuptools import setup

setup(
  name = "vsearch",
  version = "1.2",
  description = "Searching",
  author = "HF",
  author_email = "pyhf@mail.com",
  url = "saide.com",
  py_modules = ["vsearch"]
  )
